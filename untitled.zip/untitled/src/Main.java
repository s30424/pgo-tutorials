import java.util.Scanner;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        Scanner Scanner = new Scanner(System.in);
        int number;
        System.out.println("Enter your number:");
        number= Scanner.nextInt();
        if(number==0){
            System.out.println("Value is 0");}
            else if (number>0){
                System.out.println("the nymber is positive");}
            else {
                    System.out.println("The nymber is neg");
            }

        }

        }

